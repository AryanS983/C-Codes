#include <stdio.h>

int main() {
    int result;

    result = 3 + 5 * 2 - 8 / 4;

    printf("Result = %d\n", result);  // Output: 3 + (5×2) - (8/4) = 3 + 10 - 2 = 11

    return 0;
}
