#include <stdio.h>

int main() {
    printf("College: Techno Main Salt Lake\n");
    printf("Department: Computer Science and Business Systems\n");
    printf("Year: 3rd Year\n");
    return 0;
}
